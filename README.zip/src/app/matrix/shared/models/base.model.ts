export class BaseModel {

}