export const Config =  {
	TPG: 'CPM',
	intervalTime: 600000,
	callIntervalTime: 60000
};