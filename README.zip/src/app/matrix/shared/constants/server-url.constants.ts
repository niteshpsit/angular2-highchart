const ServerURL = "http://100.96.85.73:8080";
export const URLConfig =  {
	ServerURL: ServerURL,
	endPointUrl: ServerURL+'/MHWebMaven/rest/UserService',
	endPointLocalUrl: 'http://localhost:4200/api',
};