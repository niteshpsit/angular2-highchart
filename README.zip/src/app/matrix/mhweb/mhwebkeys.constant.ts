export let KEY_CONSTANTS = {
    "OPEN_TR_STATUS" : "openTrsStatus",
    "GAUGE" : "gauge", 
    "LIST_BREACHED_TRS" : "listBreachedTRs", 
    "TRS_SLA" : "trsSLA", 
    "FOCUS_LIST_TR" : "focusListTr", 
    "OPEN_TRS" : "openTrs"
}