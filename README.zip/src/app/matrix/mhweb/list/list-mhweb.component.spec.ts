.filterTable {
    input[type="text"] {
        
    }
}